package hu.u_szeged.alg.submission1;

public class Main {

    /**
     * Irj egy olyan rekurziv fuggvenyt, amely egy egesz szamokat tartalmazo
     * (csokkeno sorrendben) rendezett tombben egy elore megadott elem
     * poziciojat keresi binaris keresessel. Ha az elem nem talalhato a tombben
     * a vissza teresi ertek legyen 0.
     *
     * @param fallen Egesz szamokat tartalmazo rendezett tomb
     * @param hero A keresett szam
     * @param from A tomb vizsgalt szakaszanak kezdete. Alapertek: 0
     * (opcionalis)
     * @param to A tomb vizsgalt szakaszanak vege. Alapertek: a tomb hossza - 1
     * (opcionalis)
     * @return 0 jelentse, hogy nincs a sorban, az 1-es, hogy az elso helyen,
     * stb.
     */
    public static int binSearchRec(int hero, int[] fallen, int from, int to) {
        if(hero < fallen[to] || hero > fallen[from]) return 0;
        int x = (from+to)/2;        
        if(hero == fallen[x]) return x+1;
        if(hero > fallen[x]) return binSearchRec(hero, fallen, 0, x-1);
        if(hero < fallen[x]) return binSearchRec(hero, fallen, x+1, to);
        return -1;
    }

    public static int binarySearchWrapper(int[] input, int key) {
        return Main.binSearchRec(key, input, 0, input.length - 1);
    }

}
