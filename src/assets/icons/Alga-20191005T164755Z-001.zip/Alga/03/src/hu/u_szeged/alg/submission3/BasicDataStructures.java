package hu.u_szeged.alg.submission3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Stack;

/**
 * Elemi adatszerkezetek hasznalata szovegek tarolasara.
 *
 */
public class BasicDataStructures {

    public static void main(String[] args) {
        // Lancolt lista
        List<String> linkedList = new LinkedList<>();
        linkedList.add("alma");
        linkedList.add("korte");

        System.out.println("LinkedList: " + linkedList.get(0));
        System.out.println("LinkedList: " + linkedList.get(1));
        System.out.println();

        // Tombbel megvalositott lista
        List<String> arrayList = new ArrayList<>();
        arrayList.add("alma");
        arrayList.add("korte");

        System.out.println("ArrayList: " + arrayList.get(0));
        System.out.println("ArrayList: " + arrayList.get(1));
        System.out.println();

        // Verem
        Stack<String> stack = new Stack<>();
        stack.push("alma");
        stack.push("korte");

        System.out.println("Stack: " + stack.pop());
        System.out.println("Stack: " + stack.pop());
        System.out.println();

        // Sor
        Deque<String> queue = new ArrayDeque<>();
        queue.add("alma");
        queue.add("korte");

        System.out.println("ArrayDeque: " + queue.poll());
        System.out.println("ArrayDeque: " + queue.poll());
        System.out.println();

        // Prioritasi sor
        PriorityQueue<String> priQueue = new PriorityQueue<>();
        priQueue.add("alma");
        priQueue.add("korte");
        priQueue.add("barack");

        System.out.println("ArrayDeque: " + priQueue.poll());
        System.out.println("ArrayDeque: " + priQueue.poll());
        System.out.println("ArrayDeque: " + priQueue.poll());
        System.out.println();
    }
}
