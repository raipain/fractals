package hu.u_szeged.alg.submission3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Stack;

public class Main {

    /**
     * Az Abszol uton talalhato Gringotts bankban a zsugori koboldok igen
     * mostohan bannak a fizeteshalasztasi kerelmek feldolgozasaval. Ket fiokba
     * erkeznek egyesevel a kervenyek, mindig a stoc tetejere. Ha a
     * nyomtatvanysorszam harommal osztva 1-et ad maradekul, akkor a level a
     * "nyIltan elutasItando" feliratu 1. fiokba kerul, 2 maradek eseten pedig a
     * "hadd remenykedjen meg" megnevezesube. Ellenben a harommal oszthato
     * sorszamuak utja valasz nelkul egyenesen az iratmegsemmisItobe visz.
     * Kozben az ugyeletes kobold idonkent feldolgoz egy darab kerelmet,
     * konkretan az elso fiok legfelso dokumentumat es postazza az elutasIto
     * valaszt. Ha azonban az eppen ures volt, akkor helyette a masodik fiok
     * tetejen levore valaszol (mar ha van). Technikailag az input tombben
     * pozitIv nyomtatvanysorszamok szerepelnek beerkezesi sorrendben, illetve
     * kozejuk ekelodve az egy-egy feldolgozasi esemenyt jelolo negatIv szam.
     * Irj eljarast, ami a megvalaszolt kerelmek nyomtatvanysorszamait
     * (megvalaszolasi sorrendben) egy tombben adja vissza.
     *
     * @param applications
     * @return
     */
    public static int[] rejectionOrder(int[] applications) {
        Stack<Integer> first = new Stack<>();
        Stack<Integer> second = new Stack<>();
        int[] rectVal = new int[applications.length];
        int count = 0;
        
        for(int i = 0, index = 0; i < applications.length; i++){
            if(applications[i] < 0){
                if(!first.empty()){
                    rectVal[index] = first.pop();
                    index++;
                }
                else if(!second.empty()){
                    rectVal[index] = second.pop();
                    index++;
                }
                continue;
            }

            else if(applications[i] % 3 == 1){
                first.push(applications[i]);
            }

            else if(applications[i] % 3 == 2){
                second.push(applications[i]);
            }
        }

        for(int i=0; i < rectVal.length; i++){
            if(rectVal[i] > 0){
                count++;
            }
        }

        int[] rectArr = new int[count];
        count = 0;

        for(int i=0; i < rectVal.length; i++){
            if(rectVal[i] > 0){
                rectArr[count] = rectVal[i];
                count++;
            }
        }

        return rectArr;
    }
}
