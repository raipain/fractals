package hu.u_szeged.alg.submission5;

/**
 * Egy torpet reprezentalo osztaly
 */
class Dwarf {

    String name;
    int beardLength;
    int fightingSkill;
    int footballSkill;

    public Dwarf(String name, int beardLength, int fightingSkill, int footballSkill) {
        this.name = name;
        this.beardLength = beardLength;
        this.fightingSkill = fightingSkill;
        this.footballSkill = footballSkill;
    }

    public String toString() {
        return this.name + " (" + this.beardLength + ", " + this.fightingSkill + ", " + this.footballSkill + ")";
    }
}

public class Main {

    /**
     * Ankh-Morporkban kozeleg a hagyomanyos szabadfogasu troll-torpe
     * focirangado. (Attol szabadfogasu, hogy a csapattagok szabadon foghatnak a
     * kezukben bunkot vagy csatabardot.) A csapat tagjait Dongalabu Dorin mar
     * elore kivalasztotta kepessegeik alapjan, ennek adminisztralasaban kell
     * segitenunk. A temerdek jelentkezot harom kepesseg alapjan itelik meg:
     * szakallhossz, fegyverforgatas es labdakezeles (beardLength,
     * fightingSkill, footballSkill). Cel a jelentkezok rangsorba allitasa, majd
     * ez alapjan a megadott rangu torpek megtalalasa. A torpek rangsorolasa a
     * kovetkezo: \begin{enumerate} ket jelentkezo kozul termeszetesen a
     * hosszabb szakallu az alkalmasabb azonos szakallhossz eseten a magasabb
     * harci kepesseg a donto amennyiben pedig mindket ertek megegyezik a ket
     * torpenel, akkor a labdakezelest kell figyelembe venni teljesen megegyezo
     * kepessegű torpek kozul azt reszesitik elonyben, aki elobb jelentkezett a
     * rangadora
     *
     * Tehat a feladat a jelentkezok rangsorba allitasa, majd ez alapjan a
     * megadott rangu torpek meghatarozasa.
     *
     * @param dwarves A jelentkezo torpeket tartalmazzo tomb. Maximalis merete:
     * 2000000
     * @param teamMembers A csapattagok tudas alapu rangsorban elfoglalt helyet
     * hatarozza meg, pl: ha a tomb [1, 45] elemeket tartalmazza, akkor az 1. es
     * 45. legmagasabb osszkepessegu torpe fog a csapatba bekerulni. (Azonos
     * kepessegek eseten barmelyik jelentkezo valaszthato.)
     *
     * @return A csapatba bekerult jelentkezo nevet tartalmazo tomb (a nevek a
     * bemenet 2. tombjenek megfelelo sorrendben szerepeljenek).
     */

    public static void mergeSort(Dwarf[] a, int n) {
        if (n < 2) {
            return;
        }
        int mid = n / 2;
        Dwarf[] l = new Dwarf[mid];
        Dwarf[] r = new Dwarf[n - mid];
     
        for (int i = 0; i < mid; i++) {
            l[i] = a[i];
        }
        for (int i = mid; i < n; i++) {
            r[i - mid] = a[i];
        }
        mergeSort(l, mid);
        mergeSort(r, n - mid);
     
        merge(a, l, r, mid, n - mid);
    }

    public static void merge(Dwarf[] a, Dwarf[] l, Dwarf[] r, int left, int right) {
      
        int i = 0, j = 0, k = 0;
        while (i < left && j < right) {
            if (l[i].beardLength > r[j].beardLength) {
                a[k++] = l[i++];
            }
            else if(l[i].beardLength < r[j].beardLength){
                a[k++] = r[j++];
            }
            else{
                if (l[i].fightingSkill > r[j].fightingSkill) {
                     a[k++] = l[i++];
                }
                else if(l[i].fightingSkill < r[j].fightingSkill){
                       a[k++] = r[j++];
                } 
                else{
                    if (l[i].footballSkill >= r[j].footballSkill) {
                        a[k++] = l[i++];
                    }
                    else if(l[i].footballSkill < r[j].footballSkill){
                        a[k++] = r[j++];
                    }      
                }  
            }
        }
        while (i < left) {
            a[k++] = l[i++];
        }
        while (j < right) {
            a[k++] = r[j++];
        }
    }

    private static String[] buildTeam(Dwarf[] dwarfs, int[] teamMembers) {
        String[] ret = new String[teamMembers.length];
        
        mergeSort(dwarfs, dwarfs.length);
        for(int i=0; i<teamMembers.length; i++){
            ret[i] = dwarfs[teamMembers[i]-1].name;
        }
    
        return ret;
    }

    public static String[] buildTeamWrapper(Dwarf[] dwarfs, int[] teamMembers) {
        return buildTeam(dwarfs, teamMembers);
    }

}
